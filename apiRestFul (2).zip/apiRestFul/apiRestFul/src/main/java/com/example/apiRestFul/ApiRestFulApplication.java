package com.example.apiRestFul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestFulApplication {
	public static void main(String[] args) {
		SpringApplication.run(ApiRestFulApplication.class, args);
	}
}